from django.urls import path
from .views import index, perfil, login_view, register, admin_tienda, item_list, item_create, item_update, item_delete, contacto, merch, about, carro, faker, chovy, zeus, datos_envio, confirmacion_envio
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns = [
    path('', index, name='index'),
    path('perfil/', perfil, name='perfil'),
    path('login/', login_view, name='login'),
    path('register/', register, name='register'),
    path('admin_tienda/', admin_tienda, name='admin_tienda'),
    path('items/', item_list, name='item_list'),
    path('items/create/', item_create, name='item_create'),
    path('items/update/<int:pk>/', item_update, name='item_update'),
    path('items/delete/<int:pk>/', item_delete, name='item_delete'),
    path('contacto/', contacto, name='contacto'),
    path('merch/', merch, name='merch'),
    path('about/', about, name='about'),
    path('carro/', carro, name='carro'),
    path('faker/', faker, name='faker'),
    path('chovy/', chovy, name='chovy'),
    path('zeus/', zeus, name='zeus'),
    path('datos_envio/', views.datos_envio, name='datos_envio'),
    path('confirmacion_envio',confirmacion_envio, name='confirmacion_envio'),
    path('carro/datos_envio/', views.datos_envio, name='datos_envio'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
