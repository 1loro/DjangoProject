from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import Item
from .forms import ItemForm
from django.db import IntegrityError
from .forms import UserCreationForm

def index(request):
    return render(request, 'index.html')
def contacto(request):
    return render(request, 'contacto.html')
def merch(request):
    productos = Item.objects.all()  # Obtiene todos los productos
    return render(request, 'merch.html', {'items': productos}) 
def about(request):
    return render(request, 'about.html')
def carro(request):
    return render(request, 'carro.html')
def faker(request):
    return render(request, 'faker.html')
def chovy(request):
    return render(request, 'chovy.html')
def zeus(request):
    return render(request, 'zeus.html')
def datos_envio(request):
    return render(request, 'datos_envio.html')
def confirmacion_envio(request):
    return render(request, 'confirmacion_envio.html')

def perfil(request):
    if not request.user.is_authenticated:
        return redirect('login')
    return render(request, 'perfil.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
           
            storage = messages.get_messages(request)
            storage.used = True
            return redirect('perfil')
        else:
            
            storage = messages.get_messages(request)
            storage.used = True
            messages.error(request, 'Usuario o contraseña incorrectos')
    return render(request, 'login.html')

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            try:
                user = form.save()
                messages.success(request, 'Cuenta creada exitosamente')
                return redirect('login')
            except IntegrityError:
                messages.error(request, 'El nombre de usuario ya está registrado. Por favor, elige otro.')
        else:
            messages.error(request, 'La contraseña debe tener al menos 8 dígitos')
    else:
        form = UserCreationForm()

    return render(request, 'register.html', {'form': form})

@login_required
def admin_tienda(request):
    if request.method == 'POST':
        admin_password = request.POST['admin_password']
        with open('admin_password.txt', 'r') as file:
            correct_password = file.read().strip()
        if admin_password == correct_password:
            items = Item.objects.all()
            return render(request, 'admin_tienda.html', {'items': items})
        else:
            return render(request, 'admin_login.html')
    return render(request, 'admin_login.html')

@login_required
def item_list(request):
    items = Item.objects.all()
    return render(request, 'item_list.html', {'items': items})

@login_required
def item_create(request):
    if request.method == 'POST':
        form = ItemForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('item_list')
    else:
        form = ItemForm()
    return render(request, 'item_form.html', {'form': form})

@login_required
def item_update(request, pk):
    item = get_object_or_404(Item, pk=pk)
    if request.method == 'POST':
        form = ItemForm(request.POST, request.FILES, instance=item)  
        if form.is_valid():
            form.save()
            return redirect('item_list')
    else:
        form = ItemForm(instance=item)
    return render(request, 'item_form.html', {'form': form})

@login_required
def item_delete(request, pk):
    item = get_object_or_404(Item, pk=pk)
    if request.method == 'POST':
        item.delete()
        return redirect('item_list')
    return render(request, 'item_confirm_delete.html', {'item': item})
